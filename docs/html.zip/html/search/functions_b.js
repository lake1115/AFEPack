var searchData=
[
  ['savedata',['saveData',['../classui_experiment.html#a62f19f7927000e2b2b6946513917aef4',1,'uiExperiment::saveData()'],['../classui_experiment.html#a1b08fa8cc473ac030f73bcc46048cf45',1,'uiExperiment::saveData()']]],
  ['solve',['solve',['../classui_experiment.html#a542aa9e02b2ff7f40975ecce7b00a304',1,'uiExperiment::solve()'],['../classui_experiment.html#a542aa9e02b2ff7f40975ecce7b00a304',1,'uiExperiment::solve()']]]
];
