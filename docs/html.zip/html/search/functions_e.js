var searchData=
[
  ['writematlabdata',['writeMatlabData',['../complex__node___t_h_f_e_m_2uiexp_8cpp.html#a4d192870bd664b08d6b97b5dbe30595f',1,'uiexp.cpp']]]
];
