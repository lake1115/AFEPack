var searchData=
[
  ['basis_5fgradient',['basis_gradient',['../struct_edge_cache.html#a2d4680a87cbdda58db97839bf250b809',1,'EdgeCache::basis_gradient()'],['../struct_element_cache.html#aeff46109b387c3bbcc45e2a89f387825',1,'ElementCache::basis_gradient()']]],
  ['basis_5fvalue',['basis_value',['../struct_edge_cache.html#a777fbadecd88c241148cfb65b30d2d2b',1,'EdgeCache::basis_value()'],['../struct_element_cache.html#a31bc1cb436c3deb1c9aa8dad78c51a31',1,'ElementCache::basis_value()']]],
  ['bc',['bc',['../struct_geometry_cache.html#a6312e0dedafa80d8a8aae0f9a99ec16d',1,'GeometryCache']]],
  ['bnd',['bnd',['../complex__edge___t_h_f_e_m_2parameter_8h.html#a0150c722a481cbca4663d2d8b9a9f903',1,'bnd(const double *p):&#160;parameter.h'],['../complex__node___t_h_f_e_m_2parameter_8h.html#a0150c722a481cbca4663d2d8b9a9f903',1,'bnd(const double *p):&#160;parameter.h']]],
  ['builddgfemspace',['buildDGFEMSpace',['../classui_experiment.html#a1ec010eb71e06c6388d67bbe124c951b',1,'uiExperiment::buildDGFEMSpace(int bmark=2)'],['../classui_experiment.html#a1ec010eb71e06c6388d67bbe124c951b',1,'uiExperiment::buildDGFEMSpace(int bmark=2)']]],
  ['buildfemspace',['buildFEMSpace',['../classui_experiment.html#a82e71dbd631d00315763e0514608f0fb',1,'uiExperiment::buildFEMSpace()'],['../classui_experiment.html#a82e71dbd631d00315763e0514608f0fb',1,'uiExperiment::buildFEMSpace()']]]
];
