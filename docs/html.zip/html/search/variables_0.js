var searchData=
[
  ['basis_5fgradient',['basis_gradient',['../struct_edge_cache.html#a2d4680a87cbdda58db97839bf250b809',1,'EdgeCache::basis_gradient()'],['../struct_element_cache.html#aeff46109b387c3bbcc45e2a89f387825',1,'ElementCache::basis_gradient()']]],
  ['basis_5fvalue',['basis_value',['../struct_edge_cache.html#a777fbadecd88c241148cfb65b30d2d2b',1,'EdgeCache::basis_value()'],['../struct_element_cache.html#a31bc1cb436c3deb1c9aa8dad78c51a31',1,'ElementCache::basis_value()']]],
  ['bc',['bc',['../struct_geometry_cache.html#a6312e0dedafa80d8a8aae0f9a99ec16d',1,'GeometryCache']]]
];
