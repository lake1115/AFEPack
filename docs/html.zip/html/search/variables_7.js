var searchData=
[
  ['jxw',['Jxw',['../struct_geometry_cache.html#a31b6482011d3cc2bde276b0efce4f797',1,'GeometryCache']]]
];
