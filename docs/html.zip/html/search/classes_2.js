var searchData=
[
  ['solutioncache',['SolutionCache',['../struct_solution_cache.html',1,'']]]
];
