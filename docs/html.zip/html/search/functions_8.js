var searchData=
[
  ['neummanbc',['NeummanBC',['../classui_experiment.html#ab4c24c7ae47ac21530ea765bcb970543',1,'uiExperiment::NeummanBC(CvFunc g, int bmark=2)'],['../classui_experiment.html#ad1dc4121874564abdfab05bb16073ae4',1,'uiExperiment::NeummanBC(CFunc g, int bmark=2)']]]
];
