var searchData=
[
  ['dirichletbc',['DirichletBC',['../classui_experiment.html#a03675f636c0949ae93bed21719f9a820',1,'uiExperiment::DirichletBC(CFunc bnd, int bmark=1)'],['../classui_experiment.html#a03675f636c0949ae93bed21719f9a820',1,'uiExperiment::DirichletBC(CFunc bnd, int bmark=1)']]]
];
