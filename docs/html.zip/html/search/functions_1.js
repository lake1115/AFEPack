var searchData=
[
  ['bnd',['bnd',['../complex__edge___t_h_f_e_m_2parameter_8h.html#a0150c722a481cbca4663d2d8b9a9f903',1,'bnd(const double *p):&#160;parameter.h'],['../complex__node___t_h_f_e_m_2parameter_8h.html#a0150c722a481cbca4663d2d8b9a9f903',1,'bnd(const double *p):&#160;parameter.h']]],
  ['builddgfemspace',['buildDGFEMSpace',['../classui_experiment.html#a1ec010eb71e06c6388d67bbe124c951b',1,'uiExperiment::buildDGFEMSpace(int bmark=2)'],['../classui_experiment.html#a1ec010eb71e06c6388d67bbe124c951b',1,'uiExperiment::buildDGFEMSpace(int bmark=2)']]],
  ['buildfemspace',['buildFEMSpace',['../classui_experiment.html#a82e71dbd631d00315763e0514608f0fb',1,'uiExperiment::buildFEMSpace()'],['../classui_experiment.html#a82e71dbd631d00315763e0514608f0fb',1,'uiExperiment::buildFEMSpace()']]]
];
