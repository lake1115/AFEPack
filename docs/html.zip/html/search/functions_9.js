var searchData=
[
  ['q',['q',['../complex__edge___t_h_f_e_m_2parameter_8h.html#a07353c054e1cbc5a893a0871e613bc99',1,'q(const double *p):&#160;parameter.h'],['../complex__node___t_h_f_e_m_2parameter_8h.html#a07353c054e1cbc5a893a0871e613bc99',1,'q(const double *p):&#160;parameter.h']]]
];
