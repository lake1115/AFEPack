var searchData=
[
  ['notes_20on_20afepack_20for_20electromagnetic',['Notes on AFEPack for Electromagnetic',['../index.html',1,'']]],
  ['n_5fquad_5fpnt',['n_quad_pnt',['../struct_geometry_cache.html#aa053ebb5dfb918e59595f4322d32bce6',1,'GeometryCache']]],
  ['neummanbc',['NeummanBC',['../classui_experiment.html#ab4c24c7ae47ac21530ea765bcb970543',1,'uiExperiment::NeummanBC(CvFunc g, int bmark=2)'],['../classui_experiment.html#ad1dc4121874564abdfab05bb16073ae4',1,'uiExperiment::NeummanBC(CFunc g, int bmark=2)']]]
];
